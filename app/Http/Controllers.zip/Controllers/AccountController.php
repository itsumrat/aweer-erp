<?php

namespace App\Http\Controllers;

use App\LpoReceive;
use App\PaidGrn;
use App\PaymentVoucher;
use App\PurchaseReturn;
use App\UnPaidGrn;
use App\VendorTransaction;
use DataTables;
use Helpers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AccountController extends Controller
{
    private $root = 'accounts/';

    public function unpaidGrn(){
        return view($this->root . 'unpaid_grn');
    }

    public function unpadiGrnData(Request $request){
       $store_id = $request->store_id;
        $data = UnPaidGrn::where('is_paid', 0)->with(['purchase', 'purchase.location', 'user']);
        if ($store_id != 0) {
            $data = $data->where('purchase_id', $store_id);
        }
    
        $data = $data->get();

        return Datatables::of($data)
                ->addIndexColumn()
                ->editColumn('location', function(UnPaidGrn $product){
                    return $product->location->name;
                })
                ->editColumn('checkbox', function(UnPaidGrn $product){
                    return '<input class="sel" type="checkbox" name="count_history" value="'.$product->id.'" >';
                })
                ->editColumn('reference_no', function(UnPaidGrn $product){
                    return $product->reference;
                })
                ->editColumn('received_by', function(UnPaidGrn $product){
                    return $product->user->name;
                })
                ->editColumn('total_items', function(UnPaidGrn $product){
                    return 'N/A';
                    // return count($product->purchase->purchase_items);
                })
                ->editColumn('vendor', function(UnPaidGrn $product){
                    return $product->vendor->name;
                })
                ->editColumn('vendor_invoice', function(UnPaidGrn $product){
                    return $product->vendor_invoice;
                })
                ->editColumn('grand_total', function(UnPaidGrn $product){
                    return $product->total_due;
                })
                ->editColumn('payment_date', function(UnPaidGrn $product){
                    return 'N/A';
                })

                ->editColumn('received_by', function(UnPaidGrn $product){
                    return $product->user->name;
                })
                ->editColumn('action', function(UnPaidGrn $product){
                    return '<a href="/item/price_update/'.$product->id.'/edit"><i class="far fa-edit"></i></a>
                        <a href="#" data-toggle="modal" onclick="deleteData('.$product->id.')"><i class="far fa-trash-alt"></i></a>';
                })
                 ->rawColumns(['status', 'action', 'checkbox'])
                ->make();
    }

    public function padiGrnData(Request $request){
       $store_id = $request->store_id;
        $data = PaidGrn::where('is_paid', true)->with(['purchase', 'purchase.location', 'user']);
        if ($store_id != 0) {
            $data = $data->where('purchase_id', $store_id);
        }
    
        $data = $data->get();

        return Datatables::of($data)
                ->addIndexColumn()
                ->editColumn('location', function(PaidGrn $product){
                    return $product->location->name;
                })
                ->editColumn('checkbox', function(PaidGrn $product){
                    return '<input class="sel" type="checkbox" name="count_history" value="'.$product->id.'" >';
                })
                ->editColumn('received_by', function(PaidGrn $product){
                    return $product->user->name;
                })
                ->editColumn('reference_no', function(PaidGrn $product){
                    return $product->reference;
                })
                ->editColumn('total_items', function(PaidGrn $product){
                    return 'N/A';
                })
                ->editColumn('vendor', function(PaidGrn $product){
                    return $product->vendor->name;
                })
                ->editColumn('vendor_invoice', function(PaidGrn $product){
                    return $product->vendor_invoice;
                })
                ->editColumn('grand_total', function(PaidGrn $product){
                    return $product->total_due;
                })
                ->editColumn('payment_date', function(PaidGrn $product){
                    return 'N/A';
                })

                ->editColumn('received_by', function(PaidGrn $product){
                    return $product->user->name;
                })
                ->editColumn('action', function(PaidGrn $product){
                    return '<a href="/item/price_update/'.$product->id.'/edit"><i class="far fa-edit"></i></a>
                        <a href="#" data-toggle="modal" onclick="deleteData('.$product->id.')"><i class="far fa-trash-alt"></i></a>';
                })
                 ->rawColumns(['status', 'action', 'checkbox'])
                ->make();   
    }


    public function paidGrn(){
        return view($this->root . 'paid_grn');
    }

    public function vendorTransaction(Request $request){
        $stores = DB::table('stores')->get();
        $data = [
            'stores'=>$stores 
        ];
        $purchases = PurchaseReturn::with(['vendor', 'purchase_items', 'purchase_items.item', 'purchase_items.item.prices'])->get();
        return view($this->root . 'vendor_transaction', $data, compact('purchases'));

    }

    public function vendorTransactionView(Request $request){
        $store_id = $request->store_id;
        $vendor_id = $request->vendor_id;
       $purchase = VendorTransaction::with(['vendor', 'purchase_items', 'purchase_items.item', 'purchase_items.item.prices']);

       if ($store_id != 0) {
           $purchase = $purchase->where('location_id', $store_id);
       }

       if ($vendor_id != 0) {
           $purchase = $purchase->where('vendor_id', $vendor_id);
       }
       $purchase = $purchase->get();

       //return $purchase;

        return Datatables::of($purchase)
                ->addIndexColumn()
                ->editColumn('location', function(VendorTransaction $req){
                    return $req->locationStore->name;
                })
                ->editColumn('checkbox', function(VendorTransaction $req){
                    return '<input class="sel" type="checkbox" name="count_history" value="'.$req->id.'" >';
                })
                ->editColumn('grand_total', function(VendorTransaction $req){
                    $items = $req->purchase_items;
                    $total = 0;
                    if(!empty($items)){
                        foreach ($items as $key => $item) {
                            $single_item_total =  ($item->quantity * $item->item->prices->final_cost);
                            $single_item_total = $single_item_total - ($single_item_total * $item->discount)/100;
                            $total += $single_item_total;
                        }
                    }

                    $total = $total - ($total * $req->discount)/100;
                    $total = $total + ($total * $req->tax)/100;

                    return $total;
                })
                ->editColumn('vendor', function(VendorTransaction $req){
                    return $req->vendor->name;
                })

                ->editColumn('status', function(VendorTransaction $req){
                    return 'N/A';
                })

                ->editColumn('invoice', function(VendorTransaction $req){
                    return 'N/A';
                })
                ->rawColumns(['checkbox'])
                ->make();
    }

    public function vendorPaymentVoucher(Request $request){
        $purchaseReturn = VendorTransaction::whereIn('id', $request->selected)->get();

        foreach ($purchaseReturn as $key => $purchase) {
           $payment = new PaymentVoucher;
           $payment->pvch_date = date('Y-m-d H:i:s');
           $payment->reference = $purchase->reference;
           $payment->vendor_code = $purchase->vendor_id;
           $payment->total_invoice = '';
           $payment->total_location = $purchase->location_id;
           $payment->total_debit = '';
           $payment->total_credit = '';
           $payment->net_amount = '';
           $payment->payment_amount = '';
           $payment->check_no = 'PV'. rand(1000, 9999);
           $payment->save();
        }

    }

    public function paymentVoucher(){
        return view($this->root . 'payment_voucher');
    }

    public function paymentVoucherShow(Request $request){
       $payment = PaymentVoucher::orderBy('id', 'DESC')->get();

        return Datatables::of($payment)
                ->addIndexColumn()
                ->editColumn('date', function(PaymentVoucher $req){
                    return $req->pvch_date;
                })
                ->editColumn('reference', function(PaymentVoucher $req){
                    return $req->reference;
                })
                ->editColumn('vendor', function(PaymentVoucher $req){
                    return $req->vendor_code;
                })

                ->editColumn('total_invoice', function(PaymentVoucher $req){
                    return $req->total_invoice;
                })

                ->editColumn('total_location', function(PaymentVoucher $req){
                    return $req->total_location;
                })

                ->editColumn('total_debit', function(PaymentVoucher $req){
                    return $req->total_debit;
                })

                ->editColumn('total_credit', function(PaymentVoucher $req){
                    return $req->total_credit;
                })

                ->editColumn('net_amount', function(PaymentVoucher $req){
                    return $req->net_amount;
                })

                ->editColumn('total_credit', function(PaymentVoucher $req){
                    return $req->total_credit;
                })

                ->editColumn('total_credit', function(PaymentVoucher $req){
                    return $req->total_credit;
                })
                ->editColumn('action', function(PaymentVoucher $req){
                    return '<div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle btn-action" type="button" id="itemActionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Action
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="itemActionDropdown">
                                                        <a class="dropdown-item" href="#">View</a>
                                                        <a class="dropdown-item" href="#">Add Dr Note</a>
                                                        <a class="dropdown-item" href="#">Add Cr Note</a>
                                                        <a class="dropdown-item" href="#">Adjust Advance</a>
                                                        <a class="dropdown-item" href="#">Generate Summary</a>
                                                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#itemDelModal">Delete</a>
                                                    </div>
                                                </div>';
                })
                ->make();
    }

    public function paymentSummary(){
        return view($this->root . 'payment_summary');
    }
}
