<?php

namespace App\Http\Controllers;

use App\PettyCash;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class PettyCashController extends Controller
{
    private $root = 'finance/petty_cash/';

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view($this->root . 'create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'date' => 'required',
            'requisition_date' => 'required',
            'vendor_confirm_date' => 'required',
            'shipping_date' => 'required',
            'reference' => 'required',
            'location_id' => 'required',
        ]);

        $req = new Purchase();
        $file_name = '';

        if($request->file('document') != null){
        $fileName = time().'.'.$request->document->extension();  
   
        $request->document->move(public_path('uploads/purchase_document'), $fileName);
        $file_name = 'uploads/purchase_document/'.$fileName;
        }
        

        $req->date = $request->date;
        $req->requisition_date = $request->requisition_date;
        $req->vendor_confirm_date = $request->vendor_confirm_date;
        $req->shipping_date = $request->shipping_date;
        $req->reference = $request->reference;
        $req->location_id = $request->location_id;
        $req->status = $request->status;
        $req->document_file = $file_name;
        $req->is_foc = $request->is_foc;
        $req->vendor_id = $request->vendor_id;
        $req->discount = $request->discount;
        $req->tax = $request->tax;
        $req->note = $request->note;
        $req->user_id = \Auth::id();
        if (isset($request->foc_items)) {
            $req->is_foc = true;
        }else{
            $req->is_foc = false;
        }
        if($req->save()){
            $items = $request->purchase_order_items;
            foreach ($items as $item) {
                $req_item = new PurchaseOrderWiseItem();
                $req_item->purchase_id = $req->id;
                $req_item->item_id = $item['id'];
                $req_item->location_id = $request->location_id;
                $req_item->quantity = $item['quantity'];
                $req_item->cost = $item['cost'];
                $req_item->discount = $item['discount'];
                $req_item->save();
            }
            if(isset($request->foc_items)){
            $items = $request->foc_items;
            foreach ($items as $item) {
                $req_item = new FOCItems();
                $req_item->purchase_id = $req->id;//May Cause Error
                $req_item->item_id = $item['id'];
                $req_item->quantity = $item['quantity'];
                $req_item->save();

            }
            }
            return redirect()->back()->with('success', 'Added Successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $purchase = Purchase::with(['vendor', 'purchase_items','purchase_items.item', 'purchase_items.item.prices', 'foc_items', 'foc_items.item', 'location'])->where('id', $id)->first();
        $data = [
            'purchase' => $purchase
        ];


        // dd($data);
        return view($this->root . 'show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $purchase = Purchase::where('id', $id)->first();
        $data = [

            'purchase' => $purchase
        ];
        return view($this->root . 'edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'date' => 'required',
            'requisition_date' => 'required',
            'vendor_confirm_date' => 'required',
            'shipping_date' => 'required',
            'reference' => 'required',
            'location_id' => 'required',
        ]);

        $req = Purchase::find($id);
        $file_name = '';

        if($request->file('document') != null){
        $fileName = time().'.'.$request->document->extension();  
   
        $request->document->move(public_path('uploads/purchase_document'), $fileName);
        $file_name = 'uploads/purchase_document/'.$fileName;
        }
        

        $req->date = $request->date;
        $req->requisition_date = $request->requisition_date;
        $req->vendor_confirm_date = $request->vendor_confirm_date;
        $req->shipping_date = $request->shipping_date;
        $req->reference = $request->reference;
        $req->location_id = $request->location_id;
        $req->status = $request->status;
        $req->document_file = $file_name;
        $req->is_foc = $request->is_foc;
        $req->vendor_id = $request->vendor_id;
        $req->discount = $request->discount;
        $req->tax = $request->tax;
        $req->note = $request->note;
        if (isset($request->foc_items)) {
            $req->is_foc = true;
        }else{
            $req->is_foc = false;
        }
        if($req->save()){
            $items = $request->purchase_order_items;
            PurchaseOrderWiseItem::where('purchase_id',$id)->delete();
            foreach ($items as $item) {
                $req_item = new PurchaseOrderWiseItem();
                $req_item->purchase_id = $id;
                $req_item->item_id = $item['id'];
                $req_item->quantity = $item['quantity'];
                $req_item->discount = $item['discount'];
                $req_item->save();
            }
            if(isset($request->foc_items)){
            $items = $request->foc_items;
            FOCItems::where('purchase_id', $id)->delete();
            foreach ($items as $item) {
                $req_item = new FOCItems();
                $req_item->purchase_id = $id;
                $req_item->item_id = $item['id'];
                $req_item->quantity = $item['quantity'];
                $req_item->save();

            }
            }
            return redirect()->back()->with('success', 'Updated Successfully!');
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function destroy(Purchase $purchase)
    {
        //
    }


    public function purchaseItemsById(Request $request){
        $id = $request->id;

        $purchase = Purchase::with(['purchase_items', 'purchase_items.item', 'purchase_items.item.prices', 'foc_items', 'foc_items.item', 'foc_items.item.prices'])->where('id', $id)->first();
        return response()->json($purchase);
    }

}
