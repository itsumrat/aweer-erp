@extends('layouts/app')

@section('title', 'Dashboard - Daily Cash Closing')

@section('main_content')

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;width:100%;}
.tg input {border:0;text-align:center;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:12px;
  overflow:hidden;padding:0 20px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:20px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-0lax{text-align:left;vertical-align:top}

.tg2  {border-collapse:collapse;border-spacing:0;width:100%;}
.tg2 input {border:0;text-align:center;max-width:40px;}
.tg2 td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:12px;
  overflow:hidden;padding:0 2px;word-break:normal;}
.tg2 th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:20px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg2 .tg-0lax{text-align:left;vertical-align:top}

.tg3  {border-collapse:collapse;border-spacing:0;width:100%;}
.tg3 input {border:0;text-align:center;max-width:70px;}
.tg3 td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:12px;
  overflow:hidden;padding:0 2px;word-break:normal;}
.tg3 th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:20px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg3 .tg-0lax{text-align:left;vertical-align:top}

.text-center {text-align:center;}
.text-right {text-align:right;}
.xxl-bold {font-weight:bold;font-size:16px!important;}
.xl-bold {font-weight:bold;font-size:14px!important;}
.bold {font-weight:bold;font-size:13px!important;}
.mt-50 {padding:50px!important;}
</style>

        <main class="page-content" id="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Daily Cash Closing</h5>
                            </div>
                            @if(session('success'))
                                <h1 class="text-success">{{session('success')}}</h1>
                            @endif
                            @if(session('error'))
                                 <h1 class="text-danger">{{session('error')}}</h1>
                            @endif
                            <div class="card-body">
                                <form method="post" action="#" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">
                                        <div class="col-12">
                                            <div style="padding: 1rem;background-color: #f1f1f1;">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Select Location</label>
                                                            <select class="form-control" name="Staus">
                                                                <option value="1">2101 - Electra</option>
                                                                <option value="2">2102 - Muroor</option>
                                                                <option value="3">2103 - Madina Zayed</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-5"></div>
                                                    <div class="col-md-3 text-right">
                                                        <button type="submit" class="btn btn-primary btn-draft">Download</button>
                                                        <button type="submit" class="btn btn-primary">Print</button>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <table class="tg">
                                                        <thead>
                                                          <tr>
                                                            <th class="tg-0lax text-center" colspan="9">
                                                                Mohammed Akter Supermarket LLC
                                                            </th>
                                                          </tr>
                                                        </thead>
                                                        <tbody>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="9">
                                                                Location : ASM Electra (2101)
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="9">
                                                                Daily Cash Closing Details
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="2">
                                                                Cashier Details
                                                            </td>
                                                            <td class="tg-0lax" colspan="2">
                                                                Shagufta (101010)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Cash Closing Date
                                                            </td>
                                                            <td class="tg-0lax">
                                                                <?php echo date('d-M-Y');?>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="4">
                                                                Float Cash Denominations
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-center text-center" colspan="4">
                                                                Sales Cash Denominations
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="2">
                                                                Denomination
                                                            </td>
                                                            <td class="tg-0lax text-center">
                                                                Nos
                                                            </td>
                                                            <td class="tg-0lax text-center">
                                                                Value
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-center" colspan="2">
                                                                Denomination
                                                            </td>
                                                            <td class="tg-0lax text-center">
                                                                Nos
                                                            </td>
                                                            <td class="tg-0lax text-center">
                                                                Value
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">1000</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">1000</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">500</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">500</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">200</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">200</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">100</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">100</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">50</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">50</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">20</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">20</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">10</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">10</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">5</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">5</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">1</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">1</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">0.50</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">0.50</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">0.25</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax">0.25</td>
                                                            <td class="tg-0lax">*</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Total Float Cash (Dhs)
                                                            </td>
                                                            <td class="tg-0lax">
                                                                0
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Total Sales Cash (Dhs)
                                                            </td>
                                                            <td class="tg-0lax">
                                                                0
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Float Money (-)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Net Cash (=)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Credit Sales (+)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Total Sales (=)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Cash To Credit (+)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="8">
                                                                Sub Total (=)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="9"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="5"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Particulars
                                                            </td>
                                                            <td class="tg-0lax">
                                                                Dhs / Fils
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="4">
                                                                Undertaking
                                                            </td>
                                                            <td class="tg-0lax">
                                                                
                                                            </td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Total Cash Punched
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="4">
                                                                I’m Fully Responsible for the Shortage
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Credit To Cash
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="2">
                                                                Amount of AED
                                                            </td>
                                                            <td class="tg-0lax" colspan="2"></td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Refund / Return (-)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="4"></td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Sub Total (=)
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="4" rowspan="4">
                                                                Signature
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Cash (+Excess+)/(-Cash short-)±
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Net Cash Sales
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-right" colspan="3">
                                                                Credit Card Settlement Amount
                                                            </td>
                                                            <td class="tg-0lax"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax" colspan="2"></td>
                                                            <td class="tg-0lax" colspan="2"></td>
                                                          </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="row">
                                                    <table class="tg2">
                                                        <thead>
                                                          <tr>
                                                            <th class="tg-0lax text-center" colspan="18">
                                                                Telephone Card Sales
                                                            </th>
                                                          </tr>
                                                        </thead>
                                                        <tbody>
                                                          <tr>
                                                            <td class="tg-0lax">Particulars</td>
                                                            <td class="tg-0lax">E-15</td>
                                                            <td class="tg-0lax">E-30</td>
                                                            <td class="tg-0lax">E-55</td>
                                                            <td class="tg-0lax">E-110</td>
                                                            <td class="tg-0lax">F-15</td>
                                                            <td class="tg-0lax">F-20</td>
                                                            <td class="tg-0lax">F-30</td>
                                                            <td class="tg-0lax">F-50</td>
                                                            <td class="tg-0lax">DU-25</td>
                                                            <td class="tg-0lax">DU-55</td>
                                                            <td class="tg-0lax">DU-110</td>
                                                            <td class="tg-0lax">H-15</td>
                                                            <td class="tg-0lax">H-30</td>
                                                            <td class="tg-0lax">H-50</td>
                                                            <td class="tg-0lax">EMB-50</td>
                                                            <td class="tg-0lax">DMB-50</td>
                                                            <td class="tg-0lax">Total</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Opening Balance</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Cashier Receive</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Total</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Sales</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Transfer</td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">Closing Balance</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">S.Amount</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                            <td class="tg-0lax">0</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="17">Grand Total</td>
                                                            <td class="tg-0lax">0.00</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="17">Short / Over</td>
                                                            <td class="tg-0lax">0.00</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax" colspan="18"></td>
                                                          </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="row">
                                                    <table class="tg3">
                                                        <thead>
                                                          <tr>
                                                            <th class="tg-0lax text-center" colspan="12">
                                                                Departmentwise Daily Sales Data
                                                            </th>
                                                          </tr>
                                                        </thead>
                                                        <tbody>
                                                          <tr>
                                                            <td class="tg-0lax">1</td>
                                                            <td class="tg-0lax">2</td>
                                                            <td class="tg-0lax">3</td>
                                                            <td class="tg-0lax">4</td>
                                                            <td class="tg-0lax">5</td>
                                                            <td class="tg-0lax">6</td>
                                                            <td class="tg-0lax">7</td>
                                                            <td class="tg-0lax">8</td>
                                                            <td class="tg-0lax">9</td>
                                                            <td class="tg-0lax">10</td>
                                                            <td class="tg-0lax">11</td>
                                                            <td class="tg-0lax">12</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax">13</td>
                                                            <td class="tg-0lax">14</td>
                                                            <td class="tg-0lax">15</td>
                                                            <td class="tg-0lax">16</td>
                                                            <td class="tg-0lax">17</td>
                                                            <td class="tg-0lax">18</td>
                                                            <td class="tg-0lax">19</td>
                                                            <td class="tg-0lax">20</td>
                                                            <td class="tg-0lax">21</td>
                                                            <td class="tg-0lax">22</td>
                                                            <td class="tg-0lax">23</td>
                                                            <td class="tg-0lax">24</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                            <td class="tg-0lax"><input type="text" name=""></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-right" colspan="11">Total</td>
                                                            <td class="tg-0lax">0.00</td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax mt-50" colspan="12"></td>
                                                          </tr>
                                                          <tr>
                                                            <td class="tg-0lax text-center" colspan="2">Cashier</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-center" colspan="2">Head Cashier</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-center" colspan="2">LPO / Security</td>
                                                            <td class="tg-0lax"></td>
                                                            <td class="tg-0lax text-center" colspan="3">Manager / Superviser</td>
                                                          </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
@endsection

@push('js_script')

@endpush