@extends('layouts/app')

@section('title', 'Dashboard - Ledger Create')

@section('main_content')

        <main class="page-content" id="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Add Ledger</h5>
                            </div>
                            @if(session('success'))
                                <h1 class="text-success">{{session('success')}}</h1>
                            @endif
                            @if(session('error'))
                                 <h1 class="text-danger">{{session('error')}}</h1>
                            @endif
                            <div class="card-body">
                                <form method="post" action="{{ route('ledgers.store') }}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">
                                        <div class="col-12">
                                            <div style="padding: 1rem;background-color: #f1f1f1;">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label>Main Account</label>
                                                            <select class="form-control" name="main_ac">
                                                                <option value="1">Asset</option>
                                                                <option value="2">Liability</option>
                                                                <option value="3">Revenue</option>
                                                                <option value="4">Expense</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="form-group">
                                                            <label>Account Category</label>
                                                            <select class="form-control" name="ac_category">
                                                                <option value="1">Current Assets</option>
                                                                <option value="2">Property, Plant and Equipments</option>
                                                                <option value="3">Current Liabilities</option>
                                                                <option value="4">Non Current Liabilities</option>
                                                                <option value="5">Equity</option>
                                                                <option value="6">Sales</option>
                                                                <option value="7">Other Income</option>
                                                                <option value="8">Cost of Good Solds</option>
                                                                <option value="9">Expenses</option>
                                                                <option value="10">Financial Costs</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Posting Type</label>
                                                            <select class="form-control" name="posting_type">
                                                                <option value="1">Balance Sheet</option>
                                                                <option value="2">Income Statement</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="form-group">
                                                            <label>Ledger Code</label>
                                                            <input type="text" class="form-control" name="Ledger Code">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Ledger Head</label>
                                                            <input type="text" class="form-control" name="Ledger Head">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-primary btn-draft mt-3">draft</button>
                                        <button type="submit" class="btn btn-primary mt-3">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
@endsection

@push('js_script')

<script>

$('#datetimepicker').datetimepicker();

</script>
@endpush