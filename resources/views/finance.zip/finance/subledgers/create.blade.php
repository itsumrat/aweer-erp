@extends('layouts/app')

@section('title', 'Dashboard - SubLedger Create')

@section('main_content')

        <main class="page-content" id="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>SubLedger</h5>
                            </div>
                            @if(session('success'))
                                <h1 class="text-success">{{session('success')}}</h1>
                            @endif
                            @if(session('error'))
                                 <h1 class="text-danger">{{session('error')}}</h1>
                            @endif
                            <div class="card-body">
                                <form method="post" action="#" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">
                                        <div class="col-12">
                                            <div style="padding: 1rem;background-color: #f1f1f1;">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Ledger*</label>
                                                        <input type="hidden" name="ledger_id" v-model="selected_ledger.id">
                                                        <div class="form-group">
                                                            <v-select @search="fetch_ledger_list" :options="ledger_list" @input="fetch_ledger_info" >

                                                            </v-select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="form-group">
                                                            <label>Posting Type</label>
                                                            <select class="form-control" name="posting_type">
                                                                <option value="1">Debit</option>
                                                                <option value="2">Credit</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label>SubLedger Code</label>
                                                            <input type="text" v-model="subledger_code" class="form-control" name="SubLedger Code">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>SubLedger Head</label>
                                                            <input type="text" v-model="subledger_head" class="form-control" name="SubLedger Head">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label>Opening Balance</label>
                                                            <input type="text" v-model="opening_balance" class="form-control" name="Opening Balance">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-primary btn-draft mt-3">draft</button>
                                        <button type="submit" class="btn btn-primary mt-3">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
@endsection

@push('js_script')

<script>

$('#datetimepicker').datetimepicker();

</script>
@endpush